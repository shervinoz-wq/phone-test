import { useEffect, useLayoutEffect, useRef, type ComponentType } from 'react'
import type { TabId } from '../types'
import { ClockIcon, KeypadIcon, PersonCircleIcon, SearchGlassIcon } from './Icons'

const TABS: { id: TabId; label: string; Icon: ComponentType<{ size?: number }> }[] = [
  { id: 'calls', label: 'Calls', Icon: ClockIcon },
  { id: 'contacts', label: 'Contacts', Icon: PersonCircleIcon },
  { id: 'keypad', label: 'Keypad', Icon: KeypadIcon },
]

// the lens is a bit wider than a tab slot in the reference (148 px lens vs 138.7 px slot)
const LENS_W = 1.067
// glyph sizes measured from the original (circle icons ~21px, keypad grid ~22px wide)
const ICON_SIZE: Record<TabId, number> = { calls: 25.5, contacts: 25.5, keypad: 28 }

/**
 * Lens animation measured frame-by-frame from the iOS 26 tab bar
 * (Keypad -> Contacts, 7 captured frames):
 *  - the grey selection pill turns into a clear glass "lens" that jumps ahead fast
 *    (~72 % of the distance in the first frame, ~94 % by the third)
 *  - while travelling it stretches to ~1.34x its width, grows a bit taller than the bar,
 *    magnifies what is under it (icon + label in blue, with colour fringes on the edges)
 *  - then it shrinks back, goes ~7 % NARROWER than normal and settles at 1x,
 *    while the glass turns back into the flat grey pill.
 * p = progress of the lens centre (0 -> 1), w/h = pill scale, mag = magnification,
 * glass = 0 (flat grey pill) .. 1 (clear lens).
 */
const T = [0, 60, 120, 180, 250, 320, 400, 520]
const TRACKS = {
  p: [0, 0.72, 0.89, 0.935, 0.96, 0.985, 1, 1],
  w: [1, 1.3, 1.34, 1.21, 1.12, 1.04, 0.93, 1],
  h: [1, 1.14, 1.12, 1.08, 1.02, 1, 0.98, 1],
  mag: [1, 1.18, 1.2, 1.12, 1.04, 1, 1, 1],
  glass: [0, 1, 1, 0.8, 0.4, 0.1, 0, 0],
  // the whole glass box (all three tabs) swells a little while the lens travels, then settles back
  box: [1, 1.014, 1.022, 1.017, 1.009, 1.003, 1, 1],
}
const DURATION = T[T.length - 1]

/** Press-and-hold (0.5 s) on the bar turns the selection into a free-moving glass lens. */
const HOLD_MS = 500
const HOLD_SLOP = 10 // px of finger travel that cancels the hold (it was a scroll / a normal tap)
const GRAB = { w: 1.34, h: 1.12, mag: 1.2, glass: 1, box: 1.022 } // lens look while held (frame 3 above)
const SETTLE_FROM = 120 // the release animation replays the tracks from here to the end

/** Cubic Hermite through the keyframes with Catmull-Rom tangents (smooth, no stop at each frame). */
function sample(values: number[], t: number): number {
  if (t <= 0) return values[0]
  if (t >= DURATION) return values[values.length - 1]
  let i = 0
  while (t > T[i + 1]) i++
  const slope = (k: number) => {
    const a = Math.max(0, k - 1)
    const b = Math.min(T.length - 1, k + 1)
    return (values[b] - values[a]) / (T[b] - T[a])
  }
  const dt = T[i + 1] - T[i]
  const s = (t - T[i]) / dt
  const s2 = s * s
  const s3 = s2 * s
  return (
    (2 * s3 - 3 * s2 + 1) * values[i] +
    (s3 - 2 * s2 + s) * dt * slope(i) +
    (-2 * s3 + 3 * s2) * values[i + 1] +
    (s3 - s2) * dt * slope(i + 1)
  )
}

interface Props {
  active: TabId
  onChange: (tab: TabId) => void
  onSearch: () => void
  missedBadge: number
  hidden?: boolean
}

function TabVisual({ index, badge }: { index: number; badge: number }) {
  const { id, label, Icon } = TABS[index]
  return (
    <>
      <span className={`tab-icon ti-${id}`}>
        <Icon size={ICON_SIZE[id]} />
        {id === 'calls' && badge > 0 && <span className="badge">{badge}</span>}
      </span>
      <span className="tab-label">{label}</span>
    </>
  )
}

/** iOS 26 floating tab bar: a glass pill with 3 tabs + a separate search button. */
export function TabBar({ active, onChange, onSearch, missedBadge, hidden }: Props) {
  const nav = useRef<HTMLElement>(null)
  const lens = useRef<HTMLDivElement>(null)
  const layers = useRef<(HTMLDivElement | null)[]>([])
  const geo = useRef({ w: 0, h: 0 })
  const pad = useRef({ x: 4, y: 4 }) // padding of the glass bar (px), read from CSS
  const center = useRef<number | null>(null) // current lens centre (px, in the bar's coordinates)
  const raf = useRef(0)
  const index = TABS.findIndex((t) => t.id === active)
  const drag = useRef({ timer: 0, id: -1, startX: 0, startY: 0, holding: false, suppressClick: false, skipEffect: false })

  const tabCenter = (i: number) => pad.current.x + ((geo.current.w - pad.current.x * 2) / 3) * (i + 0.5)

  const render = (cx: number, w = 1, h = 1, mag = 1, glass = 0, box = 1) => {
    if (nav.current) nav.current.style.transform = box === 1 ? '' : `scale(${box.toFixed(4)})`
    const l = lens.current
    if (!l) return
    const { w: bw, h: bh } = geo.current
    const PX = pad.current.x
    const PY = pad.current.y
    const tabW = (bw - PX * 2) / 3
    const baseH = bh - PY * 2
    const W = tabW * w * LENS_W
    const H = baseH * h
    const L = cx - W / 2
    const Tp = (bh - H) / 2
    l.style.left = `${L}px`
    l.style.top = `${Tp}px`
    l.style.width = `${W}px`
    l.style.height = `${H}px`
    l.style.borderRadius = `${H / 2}px`
    l.style.setProperty('--glass', glass.toFixed(3))

    // edges of the lens in the coordinates of the (un-moved) tab content
    const left = L - PX
    const right = L + W - PX
    const top = Tp - PY
    const bottom = Tp + H - PY
    const mx = cx - PX
    const my = baseH / 2
    // refraction at the rim: the content just inside each edge is stretched
    // ~3.4x towards that edge, which smears the icon / label into streaks
    const K = 1 + 2.4 * glass
    const set = (el: HTMLDivElement | null, ox: number, oy: number, sx: number, sy: number) => {
      if (!el) return
      el.style.left = `${PX - L}px`
      el.style.top = `${PY - Tp}px`
      el.style.width = `${bw - PX * 2}px`
      el.style.height = `${baseH}px`
      el.style.transformOrigin = `${ox}px ${oy}px`
      el.style.transform = `scale(${sx}, ${sy})`
    }
    const [base, t, b, lf, rt] = layers.current
    set(base, mx, my, mag, mag)
    set(t, mx, top + 14, mag, mag * K)
    set(b, mx, bottom - 14, mag, mag * K)
    set(lf, left + 16, my, mag * K, mag)
    set(rt, right - 16, my, mag * K, mag)
  }

  // measure + place the lens without animation
  useLayoutEffect(() => {
    const el = nav.current
    if (!el) return
    const measure = () => {
      geo.current = { w: el.clientWidth, h: el.clientHeight }
      const cs = getComputedStyle(el)
      pad.current = { x: parseFloat(cs.paddingLeft) || 0, y: parseFloat(cs.paddingTop) || 0 }
      if (!raf.current) {
        center.current = tabCenter(index)
        render(center.current)
      }
    }
    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    return () => ro.disconnect()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // x of a pointer event in the bar's own (unscaled) coordinates
  const localX = (clientX: number) => {
    const el = nav.current
    if (!el) return 0
    const r = el.getBoundingClientRect()
    const k = el.clientWidth ? r.width / el.clientWidth : 1
    return (clientX - r.left) / k
  }
  const clampCenter = (x: number) => Math.max(tabCenter(0), Math.min(tabCenter(TABS.length - 1), x))
  const renderGrab = (cx: number) => {
    center.current = cx
    render(cx, GRAB.w, GRAB.h, GRAB.mag, GRAB.glass, GRAB.box)
  }

  // release: the lens settles on the nearest tab (same tail as the normal tab-change animation)
  const settle = (from: number, to: number) => {
    cancelAnimationFrame(raf.current)
    const total = DURATION - SETTLE_FROM
    const start = performance.now()
    const step = (now: number) => {
      const e = Math.min(now - start, total)
      const k = 1 - Math.pow(1 - e / total, 3)
      const t = SETTLE_FROM + e
      const cx = from + (to - from) * k
      center.current = cx
      render(
        cx,
        sample(TRACKS.w, t),
        sample(TRACKS.h, t),
        sample(TRACKS.mag, t),
        Math.max(0, Math.min(1, sample(TRACKS.glass, t))),
        sample(TRACKS.box, t),
      )
      if (e < total) {
        raf.current = requestAnimationFrame(step)
      } else {
        raf.current = 0
        center.current = to
        render(to)
      }
    }
    raf.current = requestAnimationFrame(step)
  }

  const onPointerDown = (e: React.PointerEvent<HTMLElement>) => {
    const d = drag.current
    d.suppressClick = false
    d.id = e.pointerId
    d.startX = e.clientX
    d.startY = e.clientY
    window.clearTimeout(d.timer)
    d.timer = window.setTimeout(() => {
      d.holding = true
      d.suppressClick = true
      try {
        nav.current?.setPointerCapture(d.id)
      } catch {
        /* pointer already gone */
      }
      cancelAnimationFrame(raf.current)
      raf.current = 0
      renderGrab(clampCenter(localX(d.startX)))
    }, HOLD_MS)
  }
  const onPointerMove = (e: React.PointerEvent<HTMLElement>) => {
    const d = drag.current
    if (e.pointerId !== d.id) return
    if (d.holding) {
      renderGrab(clampCenter(localX(e.clientX)))
    } else if (Math.hypot(e.clientX - d.startX, e.clientY - d.startY) > HOLD_SLOP) {
      window.clearTimeout(d.timer)
    }
  }
  const onPointerEnd = (e: React.PointerEvent<HTMLElement>) => {
    const d = drag.current
    if (e.pointerId !== d.id) return
    window.clearTimeout(d.timer)
    d.id = -1
    if (!d.holding) return
    d.holding = false
    const cx = clampCenter(localX(e.clientX))
    let target = 0
    for (let i = 1; i < TABS.length; i++) {
      if (Math.abs(tabCenter(i) - cx) < Math.abs(tabCenter(target) - cx)) target = i
    }
    if (target !== index) {
      d.skipEffect = true
      onChange(TABS[target].id)
    }
    settle(cx, tabCenter(target))
  }
  useEffect(() => () => window.clearTimeout(drag.current.timer), [])

  // animate when the selected tab changes
  const first = useRef(true)
  useEffect(() => {
    if (first.current) {
      first.current = false
      return
    }
    if (drag.current.skipEffect) {
      drag.current.skipEffect = false
      return
    }
    const to = tabCenter(index)
    const from = center.current ?? to
    cancelAnimationFrame(raf.current)
    if (from === to || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      raf.current = 0
      center.current = to
      render(to)
      return
    }
    const start = performance.now()
    const step = (now: number) => {
      const t = Math.min(now - start, DURATION)
      const cx = from + (to - from) * sample(TRACKS.p, t)
      center.current = cx
      render(
        cx,
        sample(TRACKS.w, t),
        sample(TRACKS.h, t),
        sample(TRACKS.mag, t),
        Math.max(0, Math.min(1, sample(TRACKS.glass, t))),
        sample(TRACKS.box, t),
      )
      if (t < DURATION) {
        raf.current = requestAnimationFrame(step)
      } else {
        raf.current = 0
        center.current = to
        render(to)
      }
    }
    raf.current = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf.current)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index])

  return (
    <div className={`tabbar-wrap${hidden ? ' hidden' : ''}`}>
      <nav
        className="tabbar glass"
        aria-label="Main"
        ref={nav}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerEnd}
        onPointerCancel={onPointerEnd}
        onContextMenu={(e) => e.preventDefault()}
      >
        <div className="tab-row">
          {TABS.map(({ id }, i) => (
            <button
              key={id}
              type="button"
              className="tab"
              aria-current={active === id ? 'page' : undefined}
              onClick={() => {
                if (drag.current.suppressClick) {
                  drag.current.suppressClick = false
                  return
                }
                onChange(id)
              }}
            >
              <TabVisual index={i} badge={missedBadge} />
            </button>
          ))}
        </div>

        {/* glass lens: shows a blue, magnified copy of the tabs only inside itself,
            plus four rim layers that stretch the content near each edge (refraction) */}
        <div className="lens" ref={lens} aria-hidden>
          <div className="lens-fill" />
          {['base', 'top', 'bottom', 'left', 'right'].map((kind, k) => (
            <div key={kind} className={`lens-layer ${kind}`}>
              <div className="lens-content" ref={(el: HTMLDivElement | null) => void (layers.current[k] = el)}>
                {TABS.map(({ id }, i) => (
                  <div key={id} className="tab lens-tab">
                    <TabVisual index={i} badge={missedBadge} />
                  </div>
                ))}
              </div>
            </div>
          ))}
          <div className="lens-rim" />
        </div>
      </nav>
      <button type="button" className="search-btn glass" aria-label="Search" onClick={onSearch}>
        <SearchGlassIcon size={26} />
      </button>
    </div>
  )
}
