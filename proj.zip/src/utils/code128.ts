/** Code 128 patterns: bar/space widths for symbol values 0..106 (106 = stop). */
const PATTERNS = [
  '212222', '222122', '222221', '121223', '121322', '131222', '122213', '122312', '132212', '221213',
  '221312', '231212', '112232', '122132', '122231', '113222', '123122', '123221', '223211', '221132',
  '221231', '213212', '223112', '312131', '311222', '321122', '321221', '312212', '322112', '322211',
  '212123', '212321', '232121', '111323', '131123', '131321', '112313', '132113', '132311', '211313',
  '231113', '231311', '112133', '112331', '132131', '113123', '113321', '133121', '313121', '211331',
  '231131', '213113', '213311', '213131', '311123', '311321', '331121', '312113', '312311', '332111',
  '314111', '221411', '431111', '111224', '111422', '121124', '121421', '141122', '141221', '112214',
  '112412', '122114', '122411', '142112', '142211', '241211', '221114', '413111', '241112', '134111',
  '111242', '121142', '121241', '114212', '124112', '124211', '411212', '421112', '421211', '212141',
  '214121', '412121', '111143', '111341', '131141', '114113', '114311', '411113', '411311', '113141',
  '114131', '311141', '411131', '211412', '211214', '211232', '2331112',
]

const START_B = 104
const START_C = 105
const CODE_C = 99
const STOP = 106

/**
 * Encodes a digit string as Code 128 (subset C, with a leading subset-B digit for odd lengths).
 * Returns the module widths, starting with a bar.
 */
export function code128Digits(digits: string): number[] {
  const odd = digits.length % 2 === 1
  const values: number[] = []
  let rest = digits
  if (odd) {
    values.push(START_B, 16 + Number(digits[0])) // '0' is value 16 in subset B
    values.push(CODE_C)
    rest = digits.slice(1)
  } else {
    values.push(START_C)
  }
  for (let i = 0; i < rest.length; i += 2) values.push(Number(rest.slice(i, i + 2)))
  let sum = values[0]
  for (let i = 1; i < values.length; i++) sum += values[i] * i
  values.push(sum % 103, STOP)
  return values.flatMap((v) => [...PATTERNS[v]].map(Number))
}

/** Bars as [x, width] in module units, plus the total width in modules. */
export function barcodeBars(digits: string): { bars: [number, number][]; modules: number } {
  const widths = code128Digits(digits)
  const bars: [number, number][] = []
  let x = 0
  widths.forEach((w, i) => {
    if (i % 2 === 0) bars.push([x, w])
    x += w
  })
  return { bars, modules: x }
}
